const messagesData = [
    {
        sender: 'Alice',
        messages: [
            'Hello, how are you?',
            'Did you get my last email?',
            'Looking forward to our meeting.'
        ]
    },
    {
        sender: 'Bob',
        messages: [
            'Hi, what’s up?',
            'Can you send me the report?',
            'Thanks for your help!'
        ]
    },
    {
        sender: 'Charlie',
        messages: [
            'Hey, long time no see!',
            'We should catch up soon.',
            'Happy birthday!'
        ]
    }
];

let selectedSenderIndex = 0;
let selectedMessageIndex = 0;

function loadSenders() {
    const sendersList = document.getElementById('sendersList');
    messagesData.forEach((data, index) => {
        const listItem = document.createElement('li');
        listItem.classList.add('list-group-item');
        listItem.textContent = data.sender;
        listItem.onclick = () => {
            selectedSenderIndex = index;
            displayMessages();
        };
        sendersList.appendChild(listItem);
    });
}

function displayMessages() {
    const messagesContainer = document.getElementById('messagesContainer');
    messagesContainer.innerHTML = '';
    messagesData[selectedSenderIndex].messages.forEach((message, index) => {
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('message');
        messageDiv.textContent = message;
        messageDiv.onclick = () => openMessageModal(index);
        messagesContainer.appendChild(messageDiv);
    });

    // Прокрутить контейнер сообщений вниз
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

function openMessageModal(messageIndex) {
    selectedMessageIndex = messageIndex;
    const modal = document.getElementById('messageModal');

    // Отобразить сообщение в модальном окне
    document.getElementById('editMessageText').textContent = `Edit Message: ${messagesData[selectedSenderIndex].messages[messageIndex]}`;

    // Очистить поля выбора языка
    document.getElementById('languageField1').value = '';
    document.getElementById('languageField2').value = '';

    modal.style.display = 'flex';
}

function closeMessageModal() {
    const modal = document.getElementById('messageModal');
    modal.style.display = 'none';
}

document.getElementById('sendMessageButton').addEventListener('click', () => {
    const newMessageInput = document.getElementById('newMessageInput');
    const newMessage = newMessageInput.value.trim();
    if (newMessage) {
        messagesData[selectedSenderIndex].messages.push(newMessage);
        displayMessages();
        newMessageInput.value = '';
    }
});

document.getElementById('messageForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const languageField1 = document.getElementById('languageField1').value;
    const languageField2 = document.getElementById('languageField2').value;

    // Логика перевода и обработки полей languageField1 и languageField2
    console.log(`Translating message: ${messagesData[selectedSenderIndex].messages[selectedMessageIndex]}`);
    console.log(`Language Field 1: ${languageField1}`);
    console.log(`Language Field 2: ${languageField2}`);

    closeMessageModal();
});

document.addEventListener('DOMContentLoaded', () => {
    loadSenders();
    if (messagesData.length > 0) {
        displayMessages();
    }

    // Получить параметры из URL
    const urlParams = new URLSearchParams(window.location.search);
    const block = urlParams.get('block');
    const field1 = urlParams.get('field1');
    const field2 = urlParams.get('field2');
    const field3 = urlParams.get('field3');

    // Отобразить параметры (если необходимо)
    if (block) {
        console.log(`Block: ${block}, Field1: ${field1}, Field2: ${field2}, Field3: ${field3}`);
    }

    // Обновлять сообщения каждые 2 секунды
    setInterval(() => {
        displayMessages();
    }, 2000);
});
