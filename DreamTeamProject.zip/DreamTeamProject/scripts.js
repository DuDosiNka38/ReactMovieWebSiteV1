let selectedBlock = '';
const blockData = {
    block1: { field1: '', field2: '', field3: '' },
    block2: { field1: '', field2: '', field3: '' },
    block3: { field1: '', field2: '', field3: '' }
};

function openModal(block) {
    selectedBlock = block;
    const modal = document.getElementById("modal");

    // Заполнить поля формы данными из blockData
    document.getElementById("field1").value = blockData[block].field1;
    document.getElementById("field2").value = blockData[block].field2;
    document.getElementById("field3").value = blockData[block].field3;

    modal.style.display = "flex";
}

function closeModal() {
    const modal = document.getElementById("modal");
    modal.style.display = "none";
}



document.getElementById("modalForm").addEventListener("submit", function(event) {
    event.preventDefault();

    // Сохранить данные из полей формы в blockData
    blockData[selectedBlock].field1 = document.getElementById("field1").value;
    blockData[selectedBlock].field2 = document.getElementById("field2").value;
    blockData[selectedBlock].field3 = document.getElementById("field3").value;

    const queryParams = new URLSearchParams({
        block: selectedBlock,
        field1: blockData[selectedBlock].field1,
        field2: blockData[selectedBlock].field2,
        field3: blockData[selectedBlock].field3
    });

    window.location.href = `page1.html?${queryParams.toString()}`;
});