export const REGISTRATION_ROUTE = "/registration"
export const LOGIN_ROUTE = "/login"
export const ADMIN_ROUTE = "/admin"
export const ROOMS_ROUTE = "/rooms"
export const REACT_APP_API_URL  = function() {return 'http://localhost:5000'}